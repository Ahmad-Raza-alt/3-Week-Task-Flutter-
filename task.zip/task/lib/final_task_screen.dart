import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class FinalTaskScreen extends StatefulWidget {
  @override
  _FinalTaskScreenState createState() => _FinalTaskScreenState();
}

class _FinalTaskScreenState extends State<FinalTaskScreen> {
  List<Map<String, dynamic>> tasks = [];
  final taskController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadTasks();
  }

  loadTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? data = prefs.getString('finalTasks');
    if (data != null) {
      setState(() {
        tasks = List<Map<String, dynamic>>.from(jsonDecode(data));
      });
    }
  }

  saveTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('finalTasks', jsonEncode(tasks));
  }

  addTask() {
    if (taskController.text.isEmpty) return;
    setState(() {
      tasks.add({'title': taskController.text, 'done': false});
      taskController.clear();
    });
    saveTasks();
  }

  toggleComplete(int index) {
    setState(() {
      tasks[index]['done'] = !tasks[index]['done'];
    });
    saveTasks();
  }

  deleteTask(int index) {
    setState(() {
      tasks.removeAt(index);
    });
    saveTasks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Final Task Manager'),
        actions: [
          IconButton(onPressed: addTask, icon: Icon(Icons.add))
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8),
            child: TextField(
              controller: taskController,
              decoration: InputDecoration(
                hintText: 'New Task',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: tasks.length,
              itemBuilder: (_, index) {
                var task = tasks[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  child: ListTile(
                    title: Text(
                      task['title'],
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        decoration:
                        task['done'] ? TextDecoration.lineThrough : null,
                        color: task['done'] ? Colors.grey : Colors.black,
                      ),
                    ),
                    leading: Checkbox(
                      value: task['done'],
                      onChanged: (_) => toggleComplete(index),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (!task['done']) // Only show when task is not done
                          TextButton(
                            onPressed: () => toggleComplete(index),
                            child: Text(
                              'Mark Done',
                              style: TextStyle(color: Colors.green),
                            ),
                          ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => deleteTask(index),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
