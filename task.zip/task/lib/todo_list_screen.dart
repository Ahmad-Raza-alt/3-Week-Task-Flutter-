import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class TodoListScreen extends StatefulWidget {
  @override
  _TodoListScreenState createState() => _TodoListScreenState();
}

class _TodoListScreenState extends State<TodoListScreen> {
  List<String> tasks = [];
  final taskController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadTasks();
  }

  loadTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? data = prefs.getString('tasks');
    if (data != null) {
      setState(() {
        tasks = List<String>.from(jsonDecode(data));
      });
    }
  }

  saveTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('tasks', jsonEncode(tasks));
  }

  addTask() {
    if (taskController.text.isEmpty) return;
    setState(() {
      tasks.add(taskController.text);
      taskController.clear();
    });
    saveTasks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('To-Do List')),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8),
            child: TextField(
              controller: taskController,
              decoration: InputDecoration(
                hintText: 'Add task',
                suffixIcon: IconButton(onPressed: addTask, icon: Icon(Icons.add)),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: tasks.length,
              itemBuilder: (_, index) => Card(
                margin: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                child: ListTile(
                  title: Text(tasks[index]),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
