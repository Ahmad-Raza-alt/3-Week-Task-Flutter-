import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.pushNamed(context, '/final');
              },
              icon: Icon(Icons.task)),
        ],
      ),
      body: ListView(
        children: [
          Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              leading: Icon(Icons.add_circle_outline, color: Colors.deepPurple),
              title: Text('Counter Screen'),
              onTap: () => Navigator.pushNamed(context, '/counter'),
            ),
          ),
          Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              leading: Icon(Icons.list_alt_outlined, color: Colors.deepPurple),
              title: Text('To-Do List'),
              onTap: () => Navigator.pushNamed(context, '/todo'),
            ),
          ),
          Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              leading: Icon(Icons.check_circle_outline, color: Colors.deepPurple),
              title: Text('Final Task App'),
              onTap: () => Navigator.pushNamed(context, '/final'),
            ),
          ),
        ],
      ),
    );
  }
}
