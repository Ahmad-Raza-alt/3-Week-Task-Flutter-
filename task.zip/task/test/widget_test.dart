import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:task/main.dart'; // <-- Make sure this path matches your app's main file

void main() {
  testWidgets('Counter increments smoke test', (WidgetTester tester) async {
    // Build the app and trigger a frame
    await tester.pumpWidget(const MyApp());

    // Navigate to CounterScreen
    await tester.tap(find.text('Counter Screen'));
    await tester.pumpAndSettle(); // Wait for navigation animation

    // Verify counter starts at 0
    expect(find.text('Counter: 0'), findsOneWidget);
    expect(find.text('Counter: 1'), findsNothing);

    // Tap the '+' button
    await tester.tap(find.text('+'));
    await tester.pump();

    // Verify counter has incremented
    expect(find.text('Counter: 1'), findsOneWidget);
    expect(find.text('Counter: 0'), findsNothing);
  });
}
